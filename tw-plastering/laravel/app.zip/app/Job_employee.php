<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job_employee extends Model
{
    protected $table = 'job_employees';
    public $timestamps = false;
}