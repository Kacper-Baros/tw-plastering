<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job_constractor extends Model
{
    protected $table = 'job_constractors';
    public $timestamps = false;
}