<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Constractor extends Model
{
    protected $table = 'constractors';
    public $timestamps = false;
}
