<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Empolyee extends Model
{
    protected $table = 'empolyees';
    public $timestamps = false;
}
